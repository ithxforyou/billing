import Ember from 'ember';


export default Ember.Controller.extend({
  websocket: Ember.inject.service(),
  listener: Ember.inject.service('websocket-listener'),
  
  appName:'Cat Trader',
  
  users: Ember.computed.alias('model'),
  payloads: [],
  
  init() {
    this._super(...arguments);
    let listener = this.get('listener');
    listener.set('messageCallback', this.showPayloads.bind(this));
    listener.listen();
  },
  
  showPayloads(m) {
    this.get('payloads').pushObject(m);
  },
  
  actions: {
    trade(currentUserIndex, cat, inc) {
      let newUser = this.get('users').objectAt(currentUserIndex + inc);
      if (!newUser) { return; };
      cat.set('user', newUser);
    },
    
    rename(cat, newName) {
      cat.set('name', newName);
    },
    
    fakeWebsocket(fnName) {
      this.get('websocket')[fnName]();
  	}
	}
});