import Ember from 'ember';

export default Ember.Service.extend({
  websocket: Ember.inject.service(),
  store:     Ember.inject.service(),
  messageCallback: null,
  
  init() {
    this._super(...arguments);
  },
  
  handleMessage(m) {
    if (this.messageCallback) {
      this.messageCallback(m);
    }
    let { type, data } = JSON.parse(m);
    if (type === 'update') {
        this.update(data);
    } else if (type === 'delete') {
        this.delete(data);
    }
  },
  
  update(data) {
    console.log(`pushing ${data}`);
    this.get('store').push({data});
  },
  
  delete({type, id}) {
    let record = this.get('store').peekRecord(type, id);
    console.log(`deleting ${record}`);
    if (record) { this.get('store').unloadRecord(record); }
  },
  
  listen() {
    let fn = this.handleMessage.bind(this);
    this.get('websocket').on('message', fn);
  }
});
