import DS from 'ember-data';

export default DS.Model.extend({
  name: DS.attr('string'),
  cats: DS.hasMany('cat', {async: false})
});
