import Ember from 'ember';
import Factory from 'demo-app/factories/payload'

export default Ember.Service.extend(Ember.Evented, {
  addPatches() {
    let payload = {
      type: 'update',
      data: Factory.cat("3", "Patches", "1")
    }
    this.trigger('message', JSON.stringify(payload, null, 2));
  },
  
  renameFluffy() {
    let payload = {
      type: 'update',
      data: Factory.cat("1", "Steve", "1")
    }
    this.trigger('message', JSON.stringify(payload, null, 2));
  },
  
  deleteCuddles() {
    let payload = {
      type: 'delete',
      data: {type: "cat", id: "2"}
    }
    this.trigger('message', JSON.stringify(payload, null, 2));
  }
});
