import Ember from 'ember';
import Factory from 'demo-app/factories/payload'

const catPayload = {
  data: [
    Factory.user("1", "Batman", ["1"]),
    Factory.user("2", "Robin", ["2"])
   ],
  included: [
    Factory.cat("1", "Fluffy", "1"),
    Factory.cat("2", "Cuddles", "2")    
  ]
}
export default Ember.Route.extend({
  beforeModel() {
    this.store.push(catPayload);
  },
  
  model() {
    return this.store.peekAll('user');
  },
  
  setupController(controller, model) {
    controller.set('model', model);
    controller.set('catCount', model.get('length'));
  }
  
});
