let user = function(id, name, catIds) {
  let cats = catIds.map(function(i) { 
    return {type: "cat", id: id};
  });
  return {
      type: "user",
      id: id,
      attributes: {name: name},
      relationships: {
        cats: {
          data: cats
        }
      }
    };
}

let cat = function(id, name, userId) {
  return {
      type: "cat",
      id: id,
      attributes: {name: name},
      relationships: {
        user: {
          data: {type: "user", id: userId}
        }
      }
    };
}
export default {user, cat};