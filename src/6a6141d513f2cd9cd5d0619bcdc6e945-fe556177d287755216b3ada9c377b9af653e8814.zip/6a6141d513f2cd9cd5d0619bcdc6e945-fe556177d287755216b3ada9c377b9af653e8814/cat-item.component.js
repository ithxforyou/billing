import Ember from 'ember';

export default Ember.Component.extend({
  cat: null,
  newName: "",
  
  actions: {
    startRename() {
      this.setProperties({renaming: true, newName: this.get('cat.name')});
    },
    confirmRename() {
      this.set('renaming', false);
      this.attrs.rename(this.get('newName'));
    }
  }
});
